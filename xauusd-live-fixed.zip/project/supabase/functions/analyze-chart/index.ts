// ============================================================
// Edge Function: analyze-chart
//
// Receives TradingView screenshot images from the frontend,
// sends them to the OpenAI Responses API (server-side secret),
// and returns structured ChartObservation JSON.
//
// The AI vision model identifies chart FACTS only — never
// BUY/SELL. The deterministic strategy engine in the frontend
// evaluates those facts against the user's strategy rules.
//
// SECRETS (configured via Supabase, NOT in client code):
//   AI_VISION_API_KEY  — OpenAI API key (required)
//   AI_VISION_API_URL  — OpenAI endpoint (default: https://api.openai.com/v1/responses)
//   AI_VISION_MODEL    — vision-capable model (default: gpt-4o)
// ============================================================

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

// ============================================================
// Types
// ============================================================

interface AnalyzeChartRequest {
  images: { slot: string; label: string; dataUrl: string }[];
  instrument: string;
}

interface LevelDetection {
  detected: boolean;
  price: number | null;
}

interface SweepDetection {
  detected: boolean;
  level: "PDH" | "PDL" | "Asian High" | "Asian Low" | "London High" | "London Low" | null;
  direction: "bullish" | "bearish" | null;
  price: number | null;
  candleIndex: number | null;
}

interface BOSDetection {
  detected: boolean;
  direction: "bullish" | "bearish" | null;
  price: number | null;
  candleIndex: number | null;
}

interface OBDetection {
  detected: boolean;
  direction: "bullish" | "bearish" | null;
  high: number | null;
  low: number | null;
  candleIndex: number | null;
}

interface FVGDetection {
  detected: boolean;
  direction: "bullish" | "bearish" | null;
  high: number | null;
  low: number | null;
}

interface ChartObservation {
  instrument: string;
  timeframe: string;
  chartValid: boolean;
  chartQuality: "good" | "fair" | "poor" | null;
  currentPrice: number | null;
  pdh: LevelDetection;
  pdl: LevelDetection;
  asianHigh: LevelDetection;
  asianLow: LevelDetection;
  londonHigh: LevelDetection;
  londonLow: LevelDetection;
  liquiditySweep: SweepDetection;
  bos: BOSDetection;
  orderBlock: OBDetection;
  fvg: FVGDetection;
  sessions: {
    asianHigh: number | null;
    asianLow: number | null;
    londonHigh: number | null;
    londonLow: number | null;
  };
  retracementIntoOB: boolean | null;
  observations: string[];
}

function emptyObservation(instrument: string, timeframe: string): ChartObservation {
  return {
    instrument,
    timeframe,
    chartValid: true,
    chartQuality: null,
    currentPrice: null,
    pdh: { detected: false, price: null },
    pdl: { detected: false, price: null },
    asianHigh: { detected: false, price: null },
    asianLow: { detected: false, price: null },
    londonHigh: { detected: false, price: null },
    londonLow: { detected: false, price: null },
    liquiditySweep: {
      detected: false,
      level: null,
      direction: null,
      price: null,
      candleIndex: null,
    },
    bos: {
      detected: false,
      direction: null,
      price: null,
      candleIndex: null,
    },
    orderBlock: {
      detected: false,
      direction: null,
      high: null,
      low: null,
      candleIndex: null,
    },
    fvg: {
      detected: false,
      direction: null,
      high: null,
      low: null,
    },
    sessions: {
      asianHigh: null,
      asianLow: null,
      londonHigh: null,
      londonLow: null,
    },
    retracementIntoOB: null,
    observations: [],
  };
}

// ============================================================
// Image validation
// ============================================================

const MAX_IMAGE_SIZE = 20 * 1024 * 1024; // 20MB

function validateImage(dataUrl: string): { valid: boolean; reason?: string } {
  if (!dataUrl || typeof dataUrl !== "string") {
    return { valid: false, reason: "Invalid image data." };
  }

  const base64Match = dataUrl.match(/^data:image\/(png|jpeg|jpg|webp);base64,/);
  if (!base64Match) {
    return { valid: false, reason: "Unsupported image format. Please upload PNG, JPEG, or WebP." };
  }

  const base64Data = dataUrl.split(",")[1];
  if (!base64Data) {
    return { valid: false, reason: "Image data is corrupted." };
  }

  const sizeBytes = Math.ceil(base64Data.length * 0.75);
  if (sizeBytes > MAX_IMAGE_SIZE) {
    return { valid: false, reason: "Image is too large. Maximum size is 20MB." };
  }

  return { valid: true };
}

// ============================================================
// AI Vision API call — OpenAI Responses API
// ============================================================

function buildSystemPrompt(instrument: string, timeframe: string): string {
  return `You are a chart observation system for ${instrument} trading.

Analyze ONLY what is visibly present in the provided TradingView chart.

Do NOT provide generic trading advice.
Do NOT invent missing price levels.
Do NOT predict future price movement.
Do NOT create trading rules.
Do NOT output BUY or SELL.

Identify visible:
- Symbol and timeframe
- Current price (if visible)
- Previous Day High (PDH) and Previous Day Low (PDL)
- Asian session High and Low
- London session High and Low
- Liquidity sweeps (which level was swept, direction, price)
- Break of Structure (BOS) (direction, price)
- Order Blocks (direction, high, low)
- Fair Value Gaps / Imbalances (direction, high, low)
- Whether price has retraced into an Order Block

If uncertain about any value, return null or mark it as not detected.
NEVER fabricate prices or chart structures.

Return ONLY a JSON object with this exact schema:
{
  "instrument": "${instrument}",
  "timeframe": "${timeframe}",
  "chartValid": boolean,
  "chartQuality": "good" | "fair" | "poor" | null,
  "currentPrice": number | null,
  "pdh": { "detected": boolean, "price": number | null },
  "pdl": { "detected": boolean, "price": number | null },
  "asianHigh": { "detected": boolean, "price": number | null },
  "asianLow": { "detected": boolean, "price": number | null },
  "londonHigh": { "detected": boolean, "price": number | null },
  "londonLow": { "detected": boolean, "price": number | null },
  "liquiditySweep": { "detected": boolean, "level": string | null, "direction": "bullish" | "bearish" | null, "price": number | null, "candleIndex": number | null },
  "bos": { "detected": boolean, "direction": "bullish" | "bearish" | null, "price": number | null, "candleIndex": number | null },
  "orderBlock": { "detected": boolean, "direction": "bullish" | "bearish" | null, "high": number | null, "low": number | null, "candleIndex": number | null },
  "fvg": { "detected": boolean, "direction": "bullish" | "bearish" | null, "high": number | null, "low": number | null },
  "sessions": { "asianHigh": number | null, "asianLow": number | null, "londonHigh": number | null, "londonLow": number | null },
  "retracementIntoOB": boolean | null,
  "observations": string[]
}

The "observations" array should contain brief factual notes about what you see (e.g. "Clear BOS above 2655", "OB formed after sweep"). These are observations only — not trading recommendations.`;
}

async function callVisionAPI(
  imageDataUrl: string,
  instrument: string,
  timeframe: string
): Promise<ChartObservation> {
  const apiKey = Deno.env.get("AI_VISION_API_KEY");
  const apiUrl = Deno.env.get("AI_VISION_API_URL") ?? "https://api.openai.com/v1/responses";
  const model = Deno.env.get("AI_VISION_MODEL") ?? "gpt-4o";

  if (!apiKey) {
    throw new Error("AI_VISION_API_KEY is not configured.");
  }

  const systemPrompt = buildSystemPrompt(instrument, timeframe);

  // OpenAI Responses API format
  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      input: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: [
            {
              type: "input_text",
              text: `Analyze this ${instrument} ${timeframe} TradingView chart screenshot. Return ONLY the JSON observation object.`,
            },
            {
              type: "input_image",
              image_url: imageDataUrl,
            },
          ],
        },
      ],
      temperature: 0,
      max_output_tokens: 2000,
    }),
  });

  if (!response.ok) {
    const status = response.status;
    let friendlyError: string;

    if (status === 401) {
      friendlyError = "AI vision API key is invalid or expired.";
    } else if (status === 429) {
      friendlyError = "AI vision API rate limit reached. Please wait a moment and try again.";
    } else if (status >= 500) {
      friendlyError = "AI vision service is temporarily unavailable. Please try again.";
    } else {
      friendlyError = `AI vision request failed (${status}).`;
    }

    // Log the raw error server-side only (never sent to client)
    const errorBody = await response.text().catch(() => "");
    console.error(`Vision API error ${status}: ${errorBody}`);

    throw new Error(friendlyError);
  }

  const data = await response.json();

  // The Responses API returns output in data.output[].content[].text
  // or data.output_text depending on the API version
  let content: string | null = null;

  if (data.output_text) {
    content = data.output_text;
  } else if (data.output && Array.isArray(data.output)) {
    for (const item of data.output) {
      if (item.content && Array.isArray(item.content)) {
        for (const c of item.content) {
          if (c.type === "output_text" && c.text) {
            content = c.text;
            break;
          }
        }
      }
      if (content) break;
    }
  } else if (data.choices?.[0]?.message?.content) {
    // Fallback for Chat Completions API format
    content = data.choices[0].message.content;
  }

  if (!content) {
    throw new Error("AI vision service returned an empty response.");
  }

  // Extract JSON from the response (handle markdown code fences)
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error("AI vision response did not contain valid JSON.");
  }

  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(jsonMatch[0]);
  } catch {
    throw new Error("AI vision response contained malformed JSON.");
  }

  const base = emptyObservation(instrument, timeframe);

  // Safely merge parsed data, only accepting known fields
  return {
    ...base,
    ...parsed,
    instrument, // always enforce the real instrument
    timeframe, // always enforce the real timeframe
  } as ChartObservation;
}

// ============================================================
// Main handler
// ============================================================

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { images, instrument } = (await req.json()) as AnalyzeChartRequest;

    if (!images || !Array.isArray(images) || images.length === 0) {
      return new Response(
        JSON.stringify({ error: "No images provided." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("AI_VISION_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({
          error:
            "AI vision is not configured. The server-side AI_VISION_API_KEY secret needs to be set.",
        }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate images
    for (const img of images) {
      const validation = validateImage(img.dataUrl);
      if (!validation.valid) {
        return new Response(
          JSON.stringify({ error: `Screenshot "${img.label}": ${validation.reason}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Analyze each image and build the observation set
    const observations: Record<string, ChartObservation> = {};
    const errors: string[] = [];

    for (const img of images) {
      const timeframe = img.slot.toUpperCase();
      try {
        const observation = await callVisionAPI(img.dataUrl, instrument, timeframe);
        observations[img.slot] = observation;
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        errors.push(`${img.label}: ${msg}`);
        // Return an empty observation for failed images so the engine can still run
        observations[img.slot] = emptyObservation(instrument, timeframe);
      }
    }

    const responseBody: Record<string, unknown> = { chartObservations: observations };
    if (errors.length > 0) {
      responseBody.warnings = errors;
    }

    return new Response(
      JSON.stringify(responseBody),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    // Never expose internal error details or secrets to the client
    console.error("analyze-chart error:", err);
    return new Response(
      JSON.stringify({ error: "Chart analysis could not be completed. Please try again." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
