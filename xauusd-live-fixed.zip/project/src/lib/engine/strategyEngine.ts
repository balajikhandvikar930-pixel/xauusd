import {
  ChartObservation,
  ChartObservationSet,
  ConditionCheck,
  DetectedElement,
  StrategyEngineResult,
  StrategyEngineStatus,
  StrategyEngineSignal,
  StrategyId,
  AnnotationPoint,
  TradeLevels,
} from '../types';
import { getStrategyConfig } from '../strategies';

// ============================================================
// Helpers
// ============================================================

function obs(set: ChartObservationSet, slot: string): ChartObservation | null {
  return set[slot] ?? null;
}

function isEmpty(observation: ChartObservation | null): boolean {
  if (!observation) return true;
  return (
    !observation.pdh.detected &&
    !observation.pdl.detected &&
    !observation.liquiditySweep.detected &&
    !observation.bos.detected &&
    !observation.orderBlock.detected &&
    !observation.fvg.detected &&
    observation.sessions.asianHigh === null &&
    observation.sessions.asianLow === null &&
    observation.sessions.londonHigh === null &&
    observation.sessions.londonLow === null
  );
}

function rr(entry: number, sl: number, tp: number): number | null {
  const risk = Math.abs(entry - sl);
  const reward = Math.abs(tp - entry);
  if (risk === 0) return null;
  return Math.round((reward / risk) * 100) / 100;
}

// ============================================================
// Strategy 1: PDH/PDL Liquidity Sweep + 5M BOS + OB/FVG
// ============================================================

export function runStrategy1(
  observations: ChartObservationSet
): StrategyEngineResult {
  const config = getStrategyConfig('strategy1');
  const obs1h = obs(observations, '1h');
  const obs5m = obs(observations, '5m');

  const reasons: string[] = [];
  const detectedElements: DetectedElement[] = [];
  const annotations: AnnotationPoint[] = [];

  // --- Insufficient data check ---
  if (isEmpty(obs1h) && isEmpty(obs5m)) {
    return buildResult(
      'strategy1',
      'INSUFFICIENT_DATA',
      'NONE',
      [],
      [],
      [],
      null,
      null,
      [],
      null,
      ['Required screenshots (1H and 5M) did not yield enough chart data.'],
      'Cannot evaluate — insufficient chart data.',
      'Required 1H and 5M screenshots are missing or unreadable.',
      [],
      [],
      {}
    );
  }

  // --- Identify PDH / PDL on 1H ---
  const pdhDetected = obs1h?.pdh.detected && obs1h.pdh.price !== null;
  const pdlDetected = obs1h?.pdl.detected && obs1h.pdl.price !== null;

  if (pdhDetected) {
    const p = obs1h!.pdh.price!;
    detectedElements.push({ type: 'PDH', label: 'Previous Day High', price: p });
    annotations.push({ type: 'PDH', label: 'Previous Day High', price: p });
    reasons.push(`PDH identified at ${p} on the 1H chart.`);
  }

  if (pdlDetected) {
    const p = obs1h!.pdl.price!;
    detectedElements.push({ type: 'PDL', label: 'Previous Day Low', price: p });
    annotations.push({ type: 'PDL', label: 'Previous Day Low', price: p });
    reasons.push(`PDL identified at ${p} on the 1H chart.`);
  }

  // --- Liquidity sweep ---
  const sweep = obs5m?.liquiditySweep ?? obs1h?.liquiditySweep;
  const sweepDetected = sweep?.detected === true;
  let sweepDirection: 'bullish' | 'bearish' | null = null;

  if (sweepDetected) {
    sweepDirection = sweep!.direction;
    const sweptLevel = sweep!.level ?? (sweepDirection === 'bearish' ? 'PDH' : 'PDL');
    detectedElements.push({
      type: 'Liquidity sweep',
      label: `${sweptLevel} swept`,
      price: sweep!.price,
      note: `Direction: ${sweepDirection}`,
    });
    annotations.push({
      type: 'Liquidity sweep',
      label: `${sweptLevel} swept (${sweepDirection})`,
      price: sweep!.price ?? undefined,
    });
    reasons.push(
      `Liquidity sweep detected: ${sweptLevel} was swept in a ${sweepDirection} direction.`
    );
    if (sweepDirection === 'bearish') {
      reasons.push('PDH swept → SELL bias established.');
    } else if (sweepDirection === 'bullish') {
      reasons.push('PDL swept → BUY bias established.');
    }
  }

  // --- BOS on 5M ---
  const bos = obs5m?.bos;
  const bosDetected = bos?.detected === true;
  let bosDirection: 'bullish' | 'bearish' | null = null;

  if (bosDetected) {
    bosDirection = bos!.direction;
    detectedElements.push({
      type: 'BOS',
      label: `5M BOS (${bosDirection})`,
      price: bos!.price,
      note: `Direction: ${bosDirection}`,
    });
    annotations.push({
      type: 'BOS',
      label: `5M Break of Structure (${bosDirection})`,
      price: bos!.price ?? undefined,
    });
    reasons.push(`5M BOS confirmed in ${bosDirection} direction.`);
  }

  // --- Order Block ---
  const ob = obs5m?.orderBlock;
  const obDetected = ob?.detected === true;
  let obDirection: 'bullish' | 'bearish' | null = null;

  if (obDetected) {
    obDirection = ob!.direction;
    detectedElements.push({
      type: 'Order Block',
      label: `${obDirection} OB`,
      price: ob!.high,
      note: `Range: ${ob!.low}–${ob!.high}`,
    });
    annotations.push({
      type: 'Order Block',
      label: `${obDirection} Order Block`,
      price: ob!.high ?? undefined,
      note: `Low: ${ob!.low ?? '—'} / High: ${ob!.high ?? '—'}`,
    });
    reasons.push(`${obDirection} Order Block detected.`);
  }

  // --- FVG (never generates entry alone) ---
  const fvg = obs5m?.fvg;
  const fvgDetected = fvg?.detected === true;

  if (fvgDetected) {
    detectedElements.push({
      type: 'FVG',
      label: `${fvg!.direction} FVG`,
      price: fvg!.high,
      note: `Range: ${fvg!.low}–${fvg!.high}`,
    });
    annotations.push({
      type: 'FVG',
      label: `Fair Value Gap (${fvg!.direction})`,
      price: fvg!.high ?? undefined,
    });
    reasons.push(`${fvg!.direction} FVG detected.`);
  }

  // --- Evaluate conditions ---
  const conditions: ConditionCheck[] = [
    { id: 'pdh_detected', label: 'PDH identified', satisfied: !!pdhDetected },
    { id: 'pdl_detected', label: 'PDL identified', satisfied: !!pdlDetected },
    { id: 'liquidity_sweep', label: 'Liquidity sweep (PDH or PDL)', satisfied: sweepDetected },
    { id: 'bos_5m', label: '5M BOS confirmed', satisfied: bosDetected },
    { id: 'order_block', label: 'Order Block detected', satisfied: obDetected },
    {
      id: 'entry_retracement',
      label: 'Price retraced into entry zone',
      satisfied: obs5m?.retracementIntoOB === true,
    },
  ];

  const missingConditions = conditions
    .filter((c) => !c.satisfied && config.conditions.find((rc) => rc.id === c.id)?.required)
    .map((c) => c.label);

  // --- Determine status & signal (deterministic state machine) ---
  let status: StrategyEngineStatus = 'NO_SETUP';
  let signal: StrategyEngineSignal = 'NONE';

  if (!pdhDetected && !pdlDetected) {
    status = 'INSUFFICIENT_DATA';
    signal = 'NONE';
  } else if (!sweepDetected) {
    status = 'NO_SETUP';
    signal = 'NONE';
    reasons.push('No liquidity sweep detected — no directional bias.');
  } else if (!bosDetected) {
    status = 'WAITING_FOR_BOS';
    signal = 'WAIT';
    reasons.push('Liquidity swept but no 5M BOS yet — waiting for structure confirmation.');
  } else if (!obDetected) {
    status = 'WAITING_FOR_OB_FVG';
    signal = 'WAIT';
    reasons.push('BOS confirmed but no valid Order Block detected — waiting for OB formation.');
    if (fvgDetected) {
      reasons.push('FVG exists but FVG alone does NOT generate an entry — requires OB.');
    }
  } else if (obs5m?.retracementIntoOB !== true) {
    status = 'ENTRY_ZONE_IDENTIFIED';
    signal = 'WAIT';
    reasons.push('Entry zone identified at the Order Block — waiting for price retracement into the zone.');
  } else {
    // Retracement confirmed → entry
    status = 'CONFIRMED';
    signal = sweepDirection === 'bullish' ? 'BUY' : sweepDirection === 'bearish' ? 'SELL' : 'WAIT';
    reasons.push('All required conditions met — entry zone confirmed via OB retracement.');
  }

  // FVG without OB → always WAIT
  if (fvgDetected && !obDetected && signal !== 'WAIT') {
    signal = 'WAIT';
    reasons.push('FVG detected without OB — entry not valid per rules.');
  }

  // --- Trade levels (configurable, currently NOT_DEFINED) ---
  const tradeLevels: TradeLevels = {};
  let entryPrice: number | null = null;
  let slPrice: number | null = null;
  let tpPrices: number[] = [];
  let riskReward: number | null = null;

  const slRule = config.stopLossRules[0];
  const tpRule = config.takeProfitRules[0];

  if (status === 'CONFIRMED' || status === 'ENTRY_ZONE_IDENTIFIED') {
    if (obDetected && ob!.high !== null && ob!.low !== null) {
      entryPrice = signal === 'BUY' ? ob!.high : ob!.low;
      tradeLevels.entry = entryPrice;
      detectedElements.push({
        type: 'Entry',
        label: 'Entry zone (OB)',
        price: entryPrice,
      });
      annotations.push({
        type: 'Entry',
        label: 'Entry zone',
        price: entryPrice ?? undefined,
      });
      reasons.push(`Entry zone: ${entryPrice} (Order Block).`);
    }
  }

  if (slRule.enabled && slRule.type !== 'NOT_DEFINED' && entryPrice !== null) {
    if (slRule.type === 'SWEEP_EXTREME' && sweep?.price !== null && sweep?.price !== undefined) {
      slPrice = sweep!.price;
      tradeLevels.stopLoss = slPrice;
      detectedElements.push({ type: 'SL', label: 'Stop Loss (sweep extreme)', price: slPrice });
      annotations.push({ type: 'SL', label: 'Stop Loss', price: slPrice ?? undefined });
    }
  } else {
    reasons.push('Stop Loss: NOT DEFINED — needs configuration.');
  }

  if (tpRule.enabled && tpRule.type === 'RISK_REWARD' && tpRule.riskRewardRatio !== null && entryPrice !== null && slPrice !== null) {
    const ratio = tpRule.riskRewardRatio;
    const risk = Math.abs(entryPrice - slPrice);
    if (signal === 'BUY') {
      tpPrices = [Math.round((entryPrice + risk * ratio) * 10) / 10];
    } else if (signal === 'SELL') {
      tpPrices = [Math.round((entryPrice - risk * ratio) * 10) / 10];
    }
    if (tpPrices.length > 0) {
      tradeLevels.takeProfit = tpPrices;
      riskReward = ratio;
      tradeLevels.riskReward = ratio;
      detectedElements.push({ type: 'TP', label: `Take Profit (1:${ratio})`, price: tpPrices[0] });
      annotations.push({ type: 'TP', label: `Take Profit (1:${ratio})`, price: tpPrices[0] });
    }
  } else {
    reasons.push('Take Profit: NOT DEFINED — needs configuration.');
  }

  if (entryPrice !== null && slPrice !== null && tpPrices.length > 0) {
    riskReward = rr(entryPrice, slPrice, tpPrices[0]);
  }

  // --- Invalidation ---
  let invalidation: string | null = null;
  if (signal === 'BUY') {
    invalidation = 'Setup invalidates if price closes below the Order Block low or the swept PDL level.';
  } else if (signal === 'SELL') {
    invalidation = 'Setup invalidates if price closes above the Order Block high or the swept PDH level.';
  } else if (sweepDetected && !bosDetected) {
    invalidation = 'Potential setup invalidates if price reverses through the swept level without a BOS.';
  }

  const summary = buildSummary('strategy1', status, signal, missingConditions);

  return buildResult(
    'strategy1',
    status,
    signal,
    conditions,
    detectedElements,
    reasons,
    entryPrice,
    slPrice,
    tpPrices,
    riskReward,
    [],
    summary,
    invalidation,
    missingConditions,
    annotations,
    tradeLevels
  );
}

// ============================================================
// Strategy 2: PDH/PDL Break + 1M Order Block Retracement
// ============================================================

export function runStrategy2(
  observations: ChartObservationSet
): StrategyEngineResult {
  const config = getStrategyConfig('strategy2');
  const obs1m = obs(observations, '1m');

  const reasons: string[] = [];
  const detectedElements: DetectedElement[] = [];
  const annotations: AnnotationPoint[] = [];

  if (isEmpty(obs1m)) {
    return buildResult(
      'strategy2',
      'INSUFFICIENT_DATA',
      'NONE',
      [],
      [],
      [],
      null,
      null,
      [],
      null,
      [],
      'Cannot evaluate — insufficient chart data.',
      'Required 1M screenshot is missing or unreadable.',
      [],
      [],
      {}
    );
  }

  const pdhDetected = obs1m!.pdh.detected && obs1m!.pdh.price !== null;
  const pdlDetected = obs1m!.pdl.detected && obs1m!.pdl.price !== null;

  if (pdhDetected) {
    const p = obs1m!.pdh.price!;
    detectedElements.push({ type: 'PDH', label: 'Previous Day High', price: p });
    annotations.push({ type: 'PDH', label: 'Previous Day High', price: p });
    reasons.push(`PDH identified at ${p}.`);
  }

  if (pdlDetected) {
    const p = obs1m!.pdl.price!;
    detectedElements.push({ type: 'PDL', label: 'Previous Day Low', price: p });
    annotations.push({ type: 'PDL', label: 'Previous Day Low', price: p });
    reasons.push(`PDL identified at ${p}.`);
  }

  // --- Level break detection ---
  const sweep = obs1m!.liquiditySweep;
  const levelBroken = sweep.detected;
  let breakDirection: 'bullish' | 'bearish' | null = sweep.direction;

  if (levelBroken) {
    const brokenLevel = sweep.level ?? (breakDirection === 'bullish' ? 'PDL' : 'PDH');
    detectedElements.push({
      type: 'Liquidity sweep',
      label: `${brokenLevel} broken`,
      price: sweep.price,
      note: `Direction: ${breakDirection}`,
    });
    annotations.push({
      type: 'Liquidity sweep',
      label: `${brokenLevel} broken (${breakDirection})`,
      price: sweep.price ?? undefined,
    });

    if (breakDirection === 'bullish') {
      reasons.push('PDL broken → BUY setup bias.');
    } else if (breakDirection === 'bearish') {
      reasons.push('PDH broken → SELL setup bias.');
    }
  }

  // --- Order Block: last opposing candle before the break ---
  const ob = obs1m!.orderBlock;
  const obDetected = ob.detected;

  if (obDetected) {
    const obDir = ob.direction;
    detectedElements.push({
      type: 'Order Block',
      label: `${obDir} OB (last opposing candle)`,
      price: ob.high,
      note: `Range: ${ob.low}–${ob.high}`,
    });
    annotations.push({
      type: 'Order Block',
      label: `${obDir} Order Block`,
      price: ob.high ?? undefined,
      note: `Low: ${ob.low ?? '—'} / High: ${ob.high ?? '—'}`,
    });

    // Candle selection rule verification
    if (breakDirection === 'bullish' && obDir === 'bullish') {
      reasons.push('Last bullish candle before the PDL break move identified as the Order Block.');
    } else if (breakDirection === 'bearish' && obDir === 'bearish') {
      reasons.push('Last bearish candle before the PDH break move identified as the Order Block.');
    } else {
      reasons.push(`Warning: OB direction (${obDir}) does not match break direction (${breakDirection}).`);
    }
  }

  // --- Retracement into OB ---
  const retraced = obs1m!.retracementIntoOB === true;

  // --- Conditions ---
  const conditions: ConditionCheck[] = [
    { id: 'pdh_detected', label: 'PDH identified', satisfied: !!pdhDetected },
    { id: 'pdl_detected', label: 'PDL identified', satisfied: !!pdlDetected },
    { id: 'level_break', label: 'PDH or PDL broken', satisfied: levelBroken },
    { id: 'order_block', label: 'Last opposing candle OB identified', satisfied: obDetected },
    { id: 'retracement_into_ob', label: 'Price retraced into Order Block', satisfied: retraced },
  ];

  const missingConditions = conditions
    .filter((c) => !c.satisfied && config.conditions.find((rc) => rc.id === c.id)?.required)
    .map((c) => c.label);

  // --- State machine ---
  let status: StrategyEngineStatus = 'NO_SETUP';
  let signal: StrategyEngineSignal = 'NONE';

  if (!pdhDetected && !pdlDetected) {
    status = 'INSUFFICIENT_DATA';
    signal = 'NONE';
  } else if (!levelBroken) {
    status = 'NO_SETUP';
    signal = 'NONE';
    reasons.push('Neither PDH nor PDL has been broken — no setup.');
  } else if (!obDetected) {
    status = 'SETUP_FORMING';
    signal = 'WAIT';
    reasons.push('Level broken but Order Block not yet identified — waiting for OB.');
  } else if (!retraced) {
    status = 'ENTRY_ZONE_IDENTIFIED';
    signal = 'WAIT';
    reasons.push('Order Block identified — waiting for price to retrace into the OB before entry.');
  } else {
    status = 'CONFIRMED';
    signal = breakDirection === 'bullish' ? 'BUY' : breakDirection === 'bearish' ? 'SELL' : 'WAIT';
    reasons.push('All conditions met: level broken + OB identified + retracement into OB. Entry generated.');
  }

  // --- Trade levels ---
  const tradeLevels: TradeLevels = {};
  let entryPrice: number | null = null;
  let slPrice: number | null = null;
  let tpPrices: number[] = [];
  let riskReward: number | null = null;

  const slRule = config.stopLossRules[0];
  const tpRule = config.takeProfitRules[0];

  if ((status === 'CONFIRMED' || status === 'ENTRY_ZONE_IDENTIFIED') && obDetected && ob.high !== null && ob.low !== null) {
    entryPrice = signal === 'BUY' ? ob.high : ob.low;
    tradeLevels.entry = entryPrice;
    detectedElements.push({ type: 'Entry', label: 'Entry (OB retracement)', price: entryPrice });
    annotations.push({ type: 'Entry', label: 'Entry zone', price: entryPrice ?? undefined });
    reasons.push(`Entry zone: ${entryPrice} (Order Block retracement).`);
  }

  if (!slRule.enabled || slRule.type === 'NOT_DEFINED') {
    reasons.push('Stop Loss: NOT DEFINED — needs configuration.');
  } else if (entryPrice !== null && slRule.type === 'SWEEP_EXTREME' && sweep.price !== null) {
    slPrice = sweep.price;
    tradeLevels.stopLoss = slPrice;
    detectedElements.push({ type: 'SL', label: 'Stop Loss (sweep extreme)', price: slPrice });
    annotations.push({ type: 'SL', label: 'Stop Loss', price: slPrice ?? undefined });
  }

  if (!tpRule.enabled || tpRule.type === 'NOT_DEFINED') {
    reasons.push('Take Profit: NOT DEFINED — needs configuration.');
  } else if (tpRule.riskRewardRatio !== null && entryPrice !== null && slPrice !== null) {
    const ratio = tpRule.riskRewardRatio;
    const risk = Math.abs(entryPrice - slPrice);
    if (signal === 'BUY') {
      tpPrices = [Math.round((entryPrice + risk * ratio) * 10) / 10];
    } else if (signal === 'SELL') {
      tpPrices = [Math.round((entryPrice - risk * ratio) * 10) / 10];
    }
    if (tpPrices.length > 0) {
      tradeLevels.takeProfit = tpPrices;
      riskReward = ratio;
      tradeLevels.riskReward = ratio;
      detectedElements.push({ type: 'TP', label: `Take Profit (1:${ratio})`, price: tpPrices[0] });
      annotations.push({ type: 'TP', label: `Take Profit (1:${ratio})`, price: tpPrices[0] });
    }
  }

  if (entryPrice !== null && slPrice !== null && tpPrices.length > 0) {
    riskReward = rr(entryPrice, slPrice, tpPrices[0]);
  }

  // --- Invalidation ---
  let invalidation: string | null = null;
  if (signal === 'BUY') {
    invalidation = 'Setup invalidates if price fails to hold above the Order Block low after retracement.';
  } else if (signal === 'SELL') {
    invalidation = 'Setup invalidates if price fails to hold below the Order Block high after retracement.';
  } else if (levelBroken && !retraced) {
    invalidation = 'Setup invalidates if price continues without retracing into the Order Block.';
  }

  const summary = buildSummary('strategy2', status, signal, missingConditions);

  return buildResult(
    'strategy2',
    status,
    signal,
    conditions,
    detectedElements,
    reasons,
    entryPrice,
    slPrice,
    tpPrices,
    riskReward,
    [],
    summary,
    invalidation,
    missingConditions,
    annotations,
    tradeLevels
  );
}

// ============================================================
// Strategy 3: Session Liquidity Sweep
// ============================================================

export function runStrategy3(
  observations: ChartObservationSet
): StrategyEngineResult {
  const config = getStrategyConfig('strategy3');
  const obsAsian = obs(observations, 'asian');
  const obsLondon = obs(observations, 'london');
  const obsNy = obs(observations, 'ny');

  const reasons: string[] = [];
  const detectedElements: DetectedElement[] = [];
  const annotations: AnnotationPoint[] = [];

  if (isEmpty(obsAsian) && isEmpty(obsLondon) && isEmpty(obsNy)) {
    return buildResult(
      'strategy3',
      'INSUFFICIENT_DATA',
      'NONE',
      [],
      [],
      [],
      null,
      null,
      [],
      null,
      [],
      'Cannot evaluate — insufficient session data.',
      'Required Asian, London, and New York session screenshots are missing or unreadable.',
      [],
      [],
      {}
    );
  }

  // --- Asian range ---
  const asianHigh = obsAsian?.sessions.asianHigh ?? obsLondon?.sessions.asianHigh ?? obsNy?.sessions.asianHigh ?? null;
  const asianLow = obsAsian?.sessions.asianLow ?? obsLondon?.sessions.asianLow ?? obsNy?.sessions.asianLow ?? null;
  const asianRangeDetected = asianHigh !== null && asianLow !== null;

  if (asianRangeDetected) {
    detectedElements.push({ type: 'Asian High', label: 'Asian Range High', price: asianHigh });
    detectedElements.push({ type: 'Asian Low', label: 'Asian Range Low', price: asianLow });
    annotations.push({ type: 'Asian High', label: 'Asian Range High', price: asianHigh ?? undefined });
    annotations.push({ type: 'Asian Low', label: 'Asian Range Low', price: asianLow ?? undefined });
    reasons.push(`Asian range: ${asianLow} – ${asianHigh}.`);
  }

  // --- London range ---
  const londonHigh = obsLondon?.sessions.londonHigh ?? obsNy?.sessions.londonHigh ?? null;
  const londonLow = obsLondon?.sessions.londonLow ?? obsNy?.sessions.londonLow ?? null;
  const londonRangeDetected = londonHigh !== null && londonLow !== null;

  if (londonRangeDetected) {
    detectedElements.push({ type: 'London High', label: 'London High', price: londonHigh });
    detectedElements.push({ type: 'London Low', label: 'London Low', price: londonLow });
    annotations.push({ type: 'London High', label: 'London High', price: londonHigh ?? undefined });
    annotations.push({ type: 'London Low', label: 'London Low', price: londonLow ?? undefined });
    reasons.push(`London range: ${londonLow} – ${londonHigh}.`);
  }

  // --- Sweep detection: Asian→London or London→NY ---
  const asianSweep = obsLondon?.liquiditySweep?.detected === true && (obsLondon.liquiditySweep.level === 'Asian High' || obsLondon.liquiditySweep.level === 'Asian Low');
  const londonSweep = obsNy?.liquiditySweep?.detected === true && (obsNy.liquiditySweep.level === 'London High' || obsNy.liquiditySweep.level === 'London Low');

  let sweepDirection: 'bullish' | 'bearish' | null = null;
  let sweptLevel: string | null = null;

  if (asianSweep) {
    sweepDirection = obsLondon!.liquiditySweep.direction;
    sweptLevel = obsLondon!.liquiditySweep.level;
    detectedElements.push({
      type: 'Liquidity sweep',
      label: `${sweptLevel} swept (Asian→London)`,
      price: obsLondon!.liquiditySweep.price,
      note: `Direction: ${sweepDirection}`,
    });
    annotations.push({
      type: 'Liquidity sweep',
      label: `${sweptLevel} swept`,
      price: obsLondon!.liquiditySweep.price ?? undefined,
    });
    if (sweptLevel === 'Asian High') reasons.push('Asian High swept → SELL setup bias.');
    if (sweptLevel === 'Asian Low') reasons.push('Asian Low swept → BUY setup bias.');
  } else if (londonSweep) {
    sweepDirection = obsNy!.liquiditySweep.direction;
    sweptLevel = obsNy!.liquiditySweep.level;
    detectedElements.push({
      type: 'Liquidity sweep',
      label: `${sweptLevel} swept (London→NY)`,
      price: obsNy!.liquiditySweep.price,
      note: `Direction: ${sweepDirection}`,
    });
    annotations.push({
      type: 'Liquidity sweep',
      label: `${sweptLevel} swept`,
      price: obsNy!.liquiditySweep.price ?? undefined,
    });
    if (sweptLevel === 'London High') reasons.push('London High swept → SELL setup bias.');
    if (sweptLevel === 'London Low') reasons.push('London Low swept → BUY setup bias.');
  }

  // --- BOS after sweep ---
  const bosAfterSweep = obsLondon?.bos?.detected === true || obsNy?.bos?.detected === true;
  if (bosAfterSweep) {
    const bosObs = obsLondon?.bos?.detected ? obsLondon.bos : obsNy?.bos;
    detectedElements.push({
      type: 'BOS',
      label: `BOS (${bosObs?.direction})`,
      price: bosObs?.price,
      note: `Direction: ${bosObs?.direction}`,
    });
    annotations.push({
      type: 'BOS',
      label: `Break of Structure (${bosObs?.direction})`,
      price: bosObs?.price ?? undefined,
    });
    reasons.push(`BOS confirmed in ${bosObs?.direction} direction after the sweep.`);
  }

  // --- OB/FVG after BOS ---
  const obAfterBos = obsLondon?.orderBlock?.detected === true || obsNy?.orderBlock?.detected === true;
  const fvgAfterBos = obsLondon?.fvg?.detected === true || obsNy?.fvg?.detected === true;
  const obFvgConfirmed = obAfterBos || fvgAfterBos;

  if (obAfterBos) {
    const obObs = obsLondon?.orderBlock?.detected ? obsLondon.orderBlock : obsNy!.orderBlock;
    detectedElements.push({
      type: 'Order Block',
      label: `${obObs.direction} OB`,
      price: obObs.high,
      note: `Range: ${obObs.low}–${obObs.high}`,
    });
    annotations.push({
      type: 'Order Block',
      label: `${obObs.direction} Order Block`,
      price: obObs.high ?? undefined,
    });
    reasons.push(`${obObs.direction} Order Block detected after BOS.`);
  }

  if (fvgAfterBos) {
    const fvgObs = obsLondon?.fvg?.detected ? obsLondon.fvg : obsNy!.fvg;
    detectedElements.push({
      type: 'FVG',
      label: `${fvgObs.direction} FVG`,
      price: fvgObs.high,
      note: `Range: ${fvgObs.low}–${fvgObs.high}`,
    });
    annotations.push({
      type: 'FVG',
      label: `Fair Value Gap (${fvgObs.direction})`,
      price: fvgObs.high ?? undefined,
    });
    reasons.push(`${fvgObs.direction} FVG detected after BOS.`);
  }

  // --- Conditions ---
  const conditions: ConditionCheck[] = [
    { id: 'asian_range', label: 'Asian High/Low identified', satisfied: asianRangeDetected },
    { id: 'london_range', label: 'London High/Low identified', satisfied: londonRangeDetected },
    { id: 'asian_sweep', label: 'Asian High or Low swept', satisfied: asianSweep },
    { id: 'london_sweep', label: 'London High or Low swept', satisfied: londonSweep },
    { id: 'bos_after_sweep', label: 'BOS after sweep', satisfied: bosAfterSweep },
    { id: 'ob_fvg_after_bos', label: 'OB/FVG confirmation after BOS', satisfied: obFvgConfirmed },
  ];

  const missingConditions = conditions
    .filter((c) => !c.satisfied && config.conditions.find((rc) => rc.id === c.id)?.required)
    .map((c) => c.label);

  // --- State machine ---
  let status: StrategyEngineStatus = 'NO_SETUP';
  let signal: StrategyEngineSignal = 'NONE';

  if (!asianRangeDetected && !londonRangeDetected) {
    status = 'INSUFFICIENT_DATA';
    signal = 'NONE';
  } else if (!asianSweep && !londonSweep) {
    status = 'NO_SETUP';
    signal = 'NONE';
    reasons.push('No session liquidity sweep detected yet — waiting for a sweep.');
  } else if (!bosAfterSweep) {
    status = 'WAITING_FOR_BOS';
    signal = 'WAIT';
    reasons.push('Session sweep detected but no BOS yet — waiting for structure confirmation.');
  } else if (!obFvgConfirmed) {
    status = 'WAITING_FOR_OB_FVG';
    signal = 'WAIT';
    reasons.push('BOS confirmed but no OB/FVG yet — waiting for entry confirmation elements.');
  } else {
    // Entry method is NOT DEFINED for Strategy 3
    status = 'ENTRY_ZONE_IDENTIFIED';
    signal = 'WAIT';
    reasons.push('Sweep + BOS + OB/FVG confirmed. Entry method is NOT DEFINED — needs configuration before a signal can be generated.');
  }

  // --- Trade levels: all NOT DEFINED for Strategy 3 ---
  const tradeLevels: TradeLevels = {};
  reasons.push('Stop Loss: NOT DEFINED — needs configuration.');
  reasons.push('Take Profit: NOT DEFINED — needs configuration.');

  // --- Invalidation ---
  let invalidation: string | null = null;
  if (asianSweep || londonSweep) {
    invalidation = 'Setup invalidates if price reverses through the swept session level without a confirmed BOS.';
  }

  const summary = buildSummary('strategy3', status, signal, missingConditions);

  return buildResult(
    'strategy3',
    status,
    signal,
    conditions,
    detectedElements,
    reasons,
    null,
    null,
    [],
    null,
    [],
    summary,
    invalidation,
    missingConditions,
    annotations,
    tradeLevels
  );
}

// ============================================================
// Combined analysis — never auto-selects a "best" strategy
// ============================================================

import { StrategyEngineResult as SER, CombinedAnalysis as CA, StrategyEngineSignal as SES } from '../types';

export function combineStrategies(results: SER[]): CA {
  const agreements: { strategyId: any; signal: SES }[] = [];
  const conflicts: { strategyId: any; signal: SES }[] = [];

  const buyStrategies = results.filter((r) => r.signal === 'BUY');
  const sellStrategies = results.filter((r) => r.signal === 'SELL');
  const waitStrategies = results.filter((r) => r.signal === 'WAIT' || r.signal === 'NONE');

  // Agreements: same direction
  if (buyStrategies.length >= 2) {
    buyStrategies.forEach((r) => agreements.push({ strategyId: r.strategyId, signal: r.signal }));
  }
  if (sellStrategies.length >= 2) {
    sellStrategies.forEach((r) => agreements.push({ strategyId: r.strategyId, signal: r.signal }));
  }

  // Conflicts: opposing directions
  if (buyStrategies.length > 0 && sellStrategies.length > 0) {
    buyStrategies.forEach((r) => conflicts.push({ strategyId: r.strategyId, signal: r.signal }));
    sellStrategies.forEach((r) => conflicts.push({ strategyId: r.strategyId, signal: r.signal }));
  }

  // Overall status
  let overallStatus: string;
  const parts: string[] = [];

  for (const r of results) {
    const name = r.strategyName.split('—')[0].trim();
    const signalLabel = r.signal === 'NONE' ? 'no signal' : r.signal;
    parts.push(`${name} produced ${signalLabel} (${r.status})`);
  }

  if (conflicts.length > 0) {
    overallStatus = 'CONFLICTING_SIGNALS';
  } else if (agreements.length >= 2) {
    overallStatus = 'AGREEMENT';
  } else if (waitStrategies.length === results.length) {
    overallStatus = 'ALL_WAITING';
  } else {
    overallStatus = 'MIXED';
  }

  const explanation = parts.join('. ') + '.';

  return {
    strategyResults: results,
    agreements,
    conflicts,
    overallStatus,
    explanation,
  };
}

// ============================================================
// Builder helper
// ============================================================

function buildResult(
  strategyId: Exclude<StrategyId, 'all'>,
  status: StrategyEngineStatus,
  signal: StrategyEngineSignal,
  conditions: ConditionCheck[],
  detectedElements: DetectedElement[],
  reasons: string[],
  entry: number | null,
  stopLoss: number | null,
  takeProfit: number[],
  riskReward: number | null,
  _extraReasons: string[],
  summary: string,
  invalidation: string | null,
  missingConditions: string[],
  annotations: AnnotationPoint[],
  tradeLevels: TradeLevels
): StrategyEngineResult {
  const config = getStrategyConfig(strategyId);
  const requiredCount = config.conditions.filter((c) => c.required).length;
  const satisfiedCount = conditions.filter((c) => {
    const rc = config.conditions.find((rc) => rc.id === c.id);
    return rc?.required && c.satisfied;
  }).length;
  const conditionCompleteness = requiredCount > 0
    ? Math.round((satisfiedCount / requiredCount) * 100)
    : 0;

  return {
    strategyId,
    strategyName: config.name,
    strategyVersion: config.version,
    status,
    signal,
    conditions,
    conditionCompleteness,
    detectedElements,
    entry,
    stopLoss,
    takeProfit,
    riskReward,
    reasons,
    invalidation,
    missingConditions,
    annotations,
    tradeLevels,
    summary,
  };
}

function buildSummary(
  strategyId: Exclude<StrategyId, 'all'>,
  status: StrategyEngineStatus,
  signal: StrategyEngineSignal,
  missingConditions: string[]
): string {
  const config = getStrategyConfig(strategyId);
  const name = config.name;

  if (status === 'INSUFFICIENT_DATA') {
    return `${name}: insufficient chart data to evaluate. Required screenshots may be missing or unreadable.`;
  }
  if (status === 'NO_SETUP') {
    return `${name}: no valid setup detected. Key conditions are not met.`;
  }
  if (missingConditions.length > 0) {
    return `${name}: ${status.replace(/_/g, ' ')}. Waiting for: ${missingConditions.join(', ')}.`;
  }
  if (status === 'CONFIRMED') {
    return `${name}: ${signal} signal confirmed. All required conditions satisfied.`;
  }
  return `${name}: ${status.replace(/_/g, ' ')}. Signal: ${signal}.`;
}

// ============================================================
// Public API
// ============================================================

export function runStrategy(
  strategyId: Exclude<StrategyId, 'all'>,
  observations: ChartObservationSet
): StrategyEngineResult {
  switch (strategyId) {
    case 'strategy1':
      return runStrategy1(observations);
    case 'strategy2':
      return runStrategy2(observations);
    case 'strategy3':
      return runStrategy3(observations);
  }
}

export function runAllStrategies(
  observations: ChartObservationSet
): { strategies: StrategyEngineResult[]; combined: CA } {
  const strategies = [
    runStrategy1(observations),
    runStrategy2(observations),
    runStrategy3(observations),
  ];
  const combined = combineStrategies(strategies);
  return { strategies, combined };
}
