import { StrategyConfig, StrategyId } from '../types';
import { STRATEGY1_CONFIG } from './strategy1';
import { STRATEGY2_CONFIG } from './strategy2';
import { STRATEGY3_CONFIG } from './strategy3';

export { STRATEGY1_CONFIG } from './strategy1';
export { STRATEGY2_CONFIG } from './strategy2';
export { STRATEGY3_CONFIG } from './strategy3';

export const STRATEGY_CONFIGS: Record<Exclude<StrategyId, 'all'>, StrategyConfig> = {
  strategy1: STRATEGY1_CONFIG,
  strategy2: STRATEGY2_CONFIG,
  strategy3: STRATEGY3_CONFIG,
};

export function getStrategyConfig(id: Exclude<StrategyId, 'all'>): StrategyConfig {
  return STRATEGY_CONFIGS[id];
}
